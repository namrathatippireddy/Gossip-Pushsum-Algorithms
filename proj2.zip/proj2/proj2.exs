Gossip.main()
