defmodule GossipPushSumTest do
  use ExUnit.Case
  doctest GossipPushSum

  test "greets the world" do
    assert GossipPushSum.hello() == :world
  end
end
